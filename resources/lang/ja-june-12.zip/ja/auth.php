<?php return array (
  'failed' => 'これらの資格は、私たちの記録と一致しません。.',
  'throttle' => 'ログイン試行回数が多すぎます。 :seconds 秒後に再試行してください。',
) ?>